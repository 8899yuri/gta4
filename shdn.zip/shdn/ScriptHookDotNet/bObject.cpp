/*
* Copyright (c) 2009-2011 Hazard (hazard_x@gmx.net / twitter.com/HazardX)
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

#include "stdafx.h"

#include "bObject.h"

#include "RemoteScriptDomain.h"

#pragma managed

namespace GTA {
namespace base {

	bool Object::Exists() {
		if (!bExists) return false;
		if (pLastExistsCheck == RemoteScriptDomain::FrameNum) return true;
		pLastExistsCheck = RemoteScriptDomain::FrameNum;
		try {
			bExists = InternalCheckExists();
		} catch (...) {
			bExists = false;
		}
		if (bExists) return true;
		OnCeasedToExist(EventArgs::Empty);
		VLOG( GetType()->Name + " " + pUID.ToString() + " ceased to exist!" );
		return false;
	}

	bool Object::PeekExists() {
		if (!bExists) return false;

		int saved = pLastExistsCheck;
		pLastExistsCheck = RemoteScriptDomain::FrameNum;

		bool res;
		try {
			res = InternalCheckExists();
		} catch (...) {
			res = false;
		}

		pLastExistsCheck = saved;
		return res;
	}

	//bool Object::ThrowExistError() {
	//	if (Exists()) return false;
	//	#ifdef DEBUG
	//		throw gcnew NonExistingObjectException( NonExistingObjectException::DEFAULT_MESSAGE + " (" + GetType()->Name + " " + pUID.ToString() + ")" );
	//	#else
	//		throw gcnew NonExistingObjectException();
	//	#endif
	//	return true;
	//}

}
}