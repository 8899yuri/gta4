/*
* Copyright (c) 2009-2011 Hazard (hazard_x@gmx.net / twitter.com/HazardX)
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

#pragma once
#pragma managed

namespace GTA {

namespace Native{

	ref class Parameter;

	CLASS_ATTRIBUTES
	[SerializableAttribute]
	public ref class Template sealed {

	private:

		String^ pName;
		array<Parameter^>^ pArguments;
		System::Type^ pReturnType;
		System::Object^ pReturnValue;
		bool bInvoked;
		//System::Threading::ManualResetEvent^ wInvoked;

	public:

		Template(String^ Name, ... array<Parameter^>^ Arguments);
		Template(String^ Name, System::Type^ ReturnType, ... array<Parameter^>^ Arguments);

		property String^ Name {
			String^ get() { return pName; }
		}
		property System::Object^ ReturnValue {
			System::Object^ get() { return pReturnValue; }
		}
		property bool wasInvoked {
			bool get() { return bInvoked; }
		}
		property int ArgumentCount {
			int get() { return pArguments->Length; }
		}

		Parameter^ Argument(int index) {
			return pArguments[index];
		}

		System::Object^ Invoke();

		//void WaitForInvoke();

	};

}
}